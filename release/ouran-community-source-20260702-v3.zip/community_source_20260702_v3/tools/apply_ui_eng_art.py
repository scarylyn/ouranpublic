#!/usr/bin/env python3
"""Apply hand-edited *eng.png UI NCER cells back into game NCGR files."""

from __future__ import annotations

import argparse
import csv
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

from PIL import Image

import nitro_render


CELL_RE = re.compile(r"^cell(\d+)eng\.png$", re.IGNORECASE)


@dataclass
class Issue:
    severity: str
    asset: str
    cell: str
    message: str


def u32(data: bytes, offset: int) -> int:
    return int.from_bytes(data[offset:offset + 4], "little")


def ncgr_payload(data: bytes) -> tuple[int, int]:
    if data[:4] != b"RGCN" or data[0x10:0x14] != b"RAHC":
        raise ValueError("not a supported NCGR")
    char_size = u32(data, 0x28)
    char_offset = 0x18 + u32(data, 0x2C)
    if char_offset + char_size > len(data):
        raise ValueError("NCGR character data points past EOF")
    return char_offset, char_size


def set_tile_pixel(tile_data: bytearray, tile: int, bpp: int, x: int, y: int, value: int) -> None:
    if bpp == 8:
        tile_data[tile * 64 + y * 8 + x] = value & 0xFF
        return
    pos = tile * 32 + y * 4 + (x // 2)
    old = tile_data[pos]
    value &= 0x0F
    if x % 2 == 0:
        tile_data[pos] = (old & 0xF0) | value
    else:
        tile_data[pos] = (old & 0x0F) | (value << 4)


def nearest_palette_index(rgb: tuple[int, int, int], palette: list[tuple[int, int, int]], indices: range) -> int:
    best_i = indices.start
    best_d = None
    r, g, b = rgb
    for i in indices:
        if i >= len(palette):
            break
        pr, pg, pb = palette[i]
        d = (r - pr) * (r - pr) + (g - pg) * (g - pg) + (b - pb) * (b - pb)
        if best_d is None or d < best_d:
            best_i, best_d = i, d
    return best_i


def cell_owners(oams: list[dict], mapping_type: int, tile_data_len: int) -> tuple[list[list[tuple | None]], tuple[int, int], tuple[int, int]]:
    if not oams:
        return [], (0, 0), (0, 0)
    min_x = min(o["x"] for o in oams)
    min_y = min(o["y"] for o in oams)
    max_x = max(o["x"] + o["width"] for o in oams)
    max_y = max(o["y"] + o["height"] for o in oams)
    width, height = max_x - min_x, max_y - min_y
    owners: list[list[tuple | None]] = [[None for _ in range(width)] for _ in range(height)]
    boundary_bytes = 32 << mapping_type
    for oam_i, o in enumerate(oams):
        tiles_x = o["width"] // 8
        tiles_y = o["height"] // 8
        tile_size = 64 if o["bpp"] == 8 else 32
        obj_base = o["tile_index"] * boundary_bytes
        for row in range(tiles_y):
            for col in range(tiles_x):
                tile_base = obj_base + (row * tiles_x + col) * tile_size
                if tile_base + tile_size > tile_data_len:
                    continue
                tile = tile_base // tile_size
                dst_col = (tiles_x - 1 - col) if o["hflip"] else col
                dst_row = (tiles_y - 1 - row) if o["vflip"] else row
                for y in range(8):
                    src_y = 7 - y if o["vflip"] else y
                    for sx in range(8):
                        src_x = 7 - sx if o["hflip"] else sx
                        img_x = o["x"] - min_x + dst_col * 8 + sx
                        img_y = o["y"] - min_y + dst_row * 8 + y
                        owners[img_y][img_x] = (oam_i, tile, src_x, src_y)
    return owners, (min_x, min_y), (width, height)


def apply_cell(
    ncgr_data: bytearray,
    nclr_path: Path,
    bank: dict,
    cell_idx: int,
    edited_path: Path,
    asset_label: str,
) -> list[Issue]:
    issues: list[Issue] = []
    char_off, char_size = ncgr_payload(ncgr_data)
    tile_data = ncgr_data[char_off:char_off + char_size]
    cells = bank["cells"]
    if cell_idx >= len(cells):
        return [Issue("error", asset_label, f"cell{cell_idx:02d}", "cell index is not in NCER")]
    oams = cells[cell_idx]
    if not oams:
        return [Issue("warning", asset_label, f"cell{cell_idx:02d}", "cell has no OAM entries")]
    owners, _origin, size = cell_owners(oams, bank["mapping_type"], len(tile_data))
    if not owners:
        return [Issue("error", asset_label, f"cell{cell_idx:02d}", "could not map cell pixels to tiles")]

    edited = Image.open(edited_path).convert("RGBA")
    if edited.size != size:
        issues.append(Issue("error", asset_label, f"cell{cell_idx:02d}", f"PNG size {edited.size} does not match cell size {size}"))
        return issues

    palette = nitro_render.read_nclr(nclr_path)
    px = edited.load()
    clipped_visible = 0
    for y, row in enumerate(owners):
        for x, owner in enumerate(row):
            r, g, b, a = px[x, y]
            if owner is None:
                if a:
                    clipped_visible += 1
                continue
            oam_i, tile, src_x, src_y = owner
            oam = oams[oam_i]
            if a == 0:
                value = 0
            elif oam["bpp"] == 8:
                value = nearest_palette_index((r, g, b), palette, range(1, min(256, len(palette))))
            else:
                start = oam["palette_bank"] * 16
                value = nearest_palette_index((r, g, b), palette, range(start + 1, start + 16)) - start
            set_tile_pixel(tile_data, tile, oam["bpp"], src_x, src_y, value)
    if clipped_visible:
        issues.append(Issue("warning", asset_label, f"cell{cell_idx:02d}", f"{clipped_visible} visible pixels are outside drawable OAM regions"))
    ncgr_data[char_off:char_off + char_size] = tile_data
    return issues


def done_dir_to_asset(done_dir: Path, ui_root: Path) -> tuple[Path, str]:
    rel = done_dir.relative_to(ui_root)
    name = rel.name
    for suffix in ("_Done", "_done"):
        if name.endswith(suffix):
            return rel.parent, name[: -len(suffix)]
    raise ValueError(f"not a done directory: {done_dir}")


def collect_done_dirs(ui_root: Path) -> list[Path]:
    dirs = []
    for p in ui_root.rglob("*"):
        if p.is_dir() and (p.name.endswith("_Done") or p.name.endswith("_done")):
            if any(CELL_RE.match(child.name) for child in p.iterdir() if child.is_file()):
                dirs.append(p)
    return sorted(dirs)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ui-art-root", default="release/community_source_20260702_v3/art_work/ui_translated/ui")
    parser.add_argument("--data-root", default="build/ouran-sergio-wrapped/data/ui")
    parser.add_argument("--patched-root", default="release/community_source_20260702_v3/art_work/ui_translated/ui")
    parser.add_argument("--report", default="release/community_source_20260702_v3/art_work/ui_translated/ui/apply_eng_art_report.csv")
    parser.add_argument("--copy-to-build", action="store_true")
    args = parser.parse_args(argv)

    ui_root = Path(args.ui_art_root)
    data_root = Path(args.data_root)
    patched_root = Path(args.patched_root)
    issues: list[Issue] = []
    patched_assets: list[tuple[Path, Path]] = []

    for done_dir in collect_done_dirs(ui_root):
        rel_parent, asset = done_dir_to_asset(done_dir, ui_root)
        asset_label = str(rel_parent / asset)
        src_ncgr = data_root / rel_parent / f"{asset}.NCGR"
        nclr = data_root / rel_parent / f"{asset}.NCLR"
        ncer = data_root / rel_parent / f"{asset}.NCER"
        if not src_ncgr.exists() or not nclr.exists() or not ncer.exists():
            issues.append(Issue("error", asset_label, "", "missing NCGR/NCLR/NCER in data root"))
            continue
        ncgr_data = bytearray(src_ncgr.read_bytes())
        bank = nitro_render.read_ncer(ncer)
        for png in sorted(done_dir.glob("*eng.png")):
            match = CELL_RE.match(png.name)
            if not match:
                continue
            cell_idx = int(match.group(1))
            issues.extend(apply_cell(ncgr_data, nclr, bank, cell_idx, png, asset_label))
        out_ncgr = patched_root / rel_parent / f"{asset}.NCGR"
        out_ncgr.parent.mkdir(parents=True, exist_ok=True)
        out_ncgr.write_bytes(ncgr_data)
        patched_assets.append((out_ncgr, src_ncgr))
        if args.copy_to_build:
            shutil.copy2(out_ncgr, src_ncgr)

    report = Path(args.report)
    report.parent.mkdir(parents=True, exist_ok=True)
    with report.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["severity", "asset", "cell", "message"])
        for issue in issues:
            writer.writerow([issue.severity, issue.asset, issue.cell, issue.message])

    print(f"patched_assets={len(patched_assets)}")
    print(f"issues={len(issues)}")
    print(f"report={report}")
    if issues:
        for issue in issues[:40]:
            print(f"{issue.severity}: {issue.asset} {issue.cell} {issue.message}")
        if len(issues) > 40:
            print(f"... {len(issues) - 40} more issues")
    return 1 if any(issue.severity == "error" for issue in issues) else 0


if __name__ == "__main__":
    raise SystemExit(main())
